CREATE TABLE IF NOT EXISTS people (
  code TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  monthly_income REAL NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS budgets (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  monthly_budget REAL NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS expenses (
  id INTEGER PRIMARY KEY,
  date TEXT NOT NULL,
  month TEXT NOT NULL,
  paid_by TEXT NOT NULL,
  amount REAL NOT NULL,
  category TEXT NOT NULL,
  payment TEXT,
  description TEXT,
  reimburse TEXT DEFAULT 'No'
);

CREATE TABLE IF NOT EXISTS loan (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  original REAL,
  balance REAL,
  emi REAL,
  rate REAL
);

CREATE TABLE IF NOT EXISTS prepayments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  amount REAL NOT NULL,
  frequency TEXT
);

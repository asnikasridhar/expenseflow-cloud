# ExpenseFlow Cloudflare Pages + D1 - Fixed Pages Structure

This folder is structured correctly for Cloudflare Pages.

## Folder structure

- `public/` contains static app files:
  - index.html
  - style.css
  - app.js
  - manifest.json

- `functions/` contains the API:
  - functions/api/[[path]].js

## Important fix for your error

Your build log showed:

`Executing user deploy command: npx wrangler deploy`

That is wrong for this setup.

Change Cloudflare Pages settings:

- Framework preset: None
- Build command: leave blank
- Build output directory: public

Do NOT use:

`npx wrangler deploy`

## D1 setup

1. Cloudflare Dashboard → Workers & Pages → D1
2. Create database: `expenseflow-db`
3. Go to your Pages project → Settings → Functions → D1 database bindings
4. Add binding:
   - Variable name: `DB`
   - D1 database: `expenseflow-db`

## PIN setup

Pages project → Settings → Environment variables

Add:
- Variable name: `APP_PIN`
- Value: choose a private PIN, example `123456`

Add it for Production.

## Redeploy

1. Upload this folder structure to GitHub.
2. Cloudflare Pages should redeploy.
3. Open the Pages URL.
4. Login with your APP_PIN.

## Common mistakes

1. Do not set build command to `npx wrangler deploy`.
2. Build output directory must be `public`.
3. D1 binding must be named exactly `DB`.
4. APP_PIN must be set in Production environment variables.

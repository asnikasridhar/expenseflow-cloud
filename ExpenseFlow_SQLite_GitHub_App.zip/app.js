const el = id => document.getElementById(id);
const rupee = n => "₹" + Number(n || 0).toLocaleString("en-IN", { maximumFractionDigits: 0 });
const todayISO = () => new Date().toISOString().slice(0,10);
const monthOf = date => (date || todayISO()).slice(0,7);
const monthName = ym => new Date(ym + "-01T00:00:00").toLocaleString("en-IN", { month:"long", year:"numeric" });
const previousMonth = ym => { const d = new Date(ym + "-01T00:00:00"); d.setMonth(d.getMonth()-1); return d.toISOString().slice(0,7); };

let activeMonth;

window.addEventListener("load", async () => {
  await initDatabase();
  activeMonth = getSetting("activeMonth");
  el("monthPicker").value = activeMonth;
  el("date").value = todayISO();
  wire();
  refreshDropdowns();
  renderAll();
  el("loading").style.display = "none";
});

function wire(){
  document.querySelectorAll("nav button").forEach(btn => btn.onclick = () => show(btn.dataset.screen));
  el("monthPicker").onchange = async e => { activeMonth = e.target.value; setSetting("activeMonth", activeMonth); await persistDb(); renderAll(); };
  el("expenseForm").onsubmit = saveExpense;
  el("cancelEdit").onclick = cancelEdit;
  el("clearMonth").onclick = clearMonth;
  el("addBudget").onclick = addBudget;
  el("savePartner").onclick = savePartner;
  el("saveLoan").onclick = saveLoan;
  el("addPrepay").onclick = addPrepay;
  el("exportSqlite").onclick = exportSqlite;
  el("importSqlite").onchange = importSqlite;
  el("exportCsv").onclick = exportCsv;
  el("resetDb").onclick = resetDb;
}

function show(id){
  document.querySelectorAll(".screen").forEach(s => s.classList.remove("active"));
  document.querySelectorAll("nav button").forEach(b => b.classList.toggle("active", b.dataset.screen === id));
  el(id).classList.add("active");
  renderAll();
}

function people(){
  return query("SELECT * FROM people ORDER BY code");
}

function budgets(){
  return query("SELECT * FROM budgets ORDER BY id");
}

function loan(){
  return query("SELECT * FROM loan WHERE id=1")[0];
}

function prepayments(){
  return query("SELECT * FROM prepayments ORDER BY id");
}

function expenses(month = activeMonth){
  return query("SELECT * FROM expenses WHERE month=? ORDER BY date DESC, id DESC", [month]);
}

function monthlySummary(month = activeMonth){
  const income = scalar("SELECT SUM(monthly_income) FROM people") || 0;
  const expense = scalar("SELECT SUM(amount) FROM expenses WHERE month=?", [month]) || 0;
  const budget = scalar("SELECT SUM(monthly_budget) FROM budgets") || 0;
  return { income, expense, surplus: income - expense, rate: income ? (income-expense)/income*100 : 0, budgetUsed: budget ? expense/budget*100 : 0, budget };
}

function refreshDropdowns(){
  const ppl = people();
  el("paidBy").innerHTML = ppl.map(p => `<option value="${p.code}">${escapeHtml(p.name)}</option>`).join("");
  el("category").innerHTML = budgets().map(b => `<option>${escapeHtml(b.name)}</option>`).join("");
}

function renderAll(){
  refreshDropdowns();
  renderDashboard();
  renderExpenses();
  renderBudget();
  renderPartner();
  renderLoan();
  renderQuickAdd();
}

function renderDashboard(){
  const s = monthlySummary();
  el("selectedMonthLabel").textContent = monthName(activeMonth);
  el("surplusKpi").textContent = rupee(s.surplus);
  el("incomeKpi").textContent = rupee(s.income);
  el("expenseKpi").textContent = rupee(s.expense);
  el("rateKpi").textContent = Math.round(s.rate) + "%";
  el("budgetKpi").textContent = Math.round(s.budgetUsed) + "%";

  const rows = query(`
    SELECT b.name, b.monthly_budget budget, COALESCE(SUM(e.amount),0) spent
    FROM budgets b
    LEFT JOIN expenses e ON e.category=b.name AND e.month=?
    GROUP BY b.id
    ORDER BY b.id
  `, [activeMonth]);

  el("budgetBars").innerHTML = rows.map(r => {
    const pct = r.budget ? Math.min(100, r.spent/r.budget*100) : 0;
    return `<div class="bar-row ${r.spent>r.budget?'over':''}">
      <div class="bar-top"><span>${escapeHtml(r.name)}</span><span>${rupee(r.spent)} / ${rupee(r.budget)}</span></div>
      <div class="bar"><i style="width:${pct}%"></i></div>
    </div>`;
  }).join("");

  const pRows = query(`
    SELECT p.code, p.name, COALESCE(SUM(e.amount),0) spent
    FROM people p
    LEFT JOIN expenses e ON e.paid_by=p.code AND e.month=?
    GROUP BY p.code
  `, [activeMonth]);
  const max = Math.max(...pRows.map(r => r.spent), 1);
  el("partnerSplit").innerHTML = pRows.map(r => `<div class="bar-row">
    <div class="bar-top"><span>${escapeHtml(r.name)}</span><span>${rupee(r.spent)}</span></div>
    <div class="bar"><i style="width:${r.spent/max*100}%"></i></div>
  </div>`).join("");

  const prev = monthlySummary(previousMonth(activeMonth));
  el("monthCompare").innerHTML = `<table class="table">
    <tr><th>Metric</th><th>${monthName(previousMonth(activeMonth))}</th><th>${monthName(activeMonth)}</th></tr>
    <tr><td>Income</td><td>${rupee(prev.income)}</td><td>${rupee(s.income)}</td></tr>
    <tr><td>Expense</td><td>${rupee(prev.expense)}</td><td>${rupee(s.expense)}</td></tr>
    <tr><td>Surplus</td><td>${rupee(prev.surplus)}</td><td>${rupee(s.surplus)}</td></tr>
    <tr><td>Savings Rate</td><td>${Math.round(prev.rate)}%</td><td>${Math.round(s.rate)}%</td></tr>
  </table>`;
}

async function saveExpense(e){
  e.preventDefault();
  const id = el("editingId").value ? Number(el("editingId").value) : Date.now();
  const date = el("date").value;
  const params = [id, date, monthOf(date), el("paidBy").value, Number(el("amount").value), el("category").value, el("payment").value, el("description").value, el("reimburse").value];
  run(`INSERT INTO expenses(id,date,month,paid_by,amount,category,payment,description,reimburse)
       VALUES (?,?,?,?,?,?,?,?,?)
       ON CONFLICT(id) DO UPDATE SET date=excluded.date,month=excluded.month,paid_by=excluded.paid_by,amount=excluded.amount,category=excluded.category,payment=excluded.payment,description=excluded.description,reimburse=excluded.reimburse`, params);
  activeMonth = monthOf(date);
  setSetting("activeMonth", activeMonth);
  el("monthPicker").value = activeMonth;
  await persistDb();
  cancelEdit();
  renderAll();
  show("expenses");
}

function renderExpenses(){
  const rows = expenses();
  el("expenseList").innerHTML = rows.map(e => `<div class="entry">
    <div><b>${escapeHtml(e.category)}</b><br><small>${escapeHtml(e.description || e.payment || "")} • ${e.date}</small><br>
    <small>Paid by ${escapeHtml(personName(e.paid_by))}${e.reimburse==="Yes"?" • Reimburse":""}</small>
    <div class="actions"><button class="secondary" onclick="editExpense(${e.id})">Edit</button><button class="danger" onclick="deleteExpense(${e.id})">Delete</button></div></div>
    <div class="amt">${rupee(e.amount)}</div>
  </div>`).join("") || `<p>No expenses for ${monthName(activeMonth)}.</p>`;
}

function personName(code){
  const p = query("SELECT name FROM people WHERE code=?", [code])[0];
  return p ? p.name : code;
}

function editExpense(id){
  const e = query("SELECT * FROM expenses WHERE id=?", [id])[0];
  if (!e) return;
  show("add");
  el("editingId").value = e.id;
  el("date").value = e.date;
  el("paidBy").value = e.paid_by;
  el("amount").value = e.amount;
  el("category").value = e.category;
  el("payment").value = e.payment;
  el("description").value = e.description || "";
  el("reimburse").value = e.reimburse || "No";
  el("formTitle").textContent = "Edit Expense";
  el("saveExpense").textContent = "Update Expense";
  el("cancelEdit").classList.remove("hidden");
}

async function deleteExpense(id){
  if (!confirm("Delete this expense?")) return;
  run("DELETE FROM expenses WHERE id=?", [id]);
  await persistDb();
  renderAll();
}

function cancelEdit(){
  el("expenseForm").reset();
  el("editingId").value = "";
  el("date").value = todayISO();
  el("formTitle").textContent = "Add Expense";
  el("saveExpense").textContent = "Save Expense";
  el("cancelEdit").classList.add("hidden");
  refreshDropdowns();
}

async function clearMonth(){
  if (!confirm(`Clear all expenses for ${monthName(activeMonth)}?`)) return;
  run("DELETE FROM expenses WHERE month=?", [activeMonth]);
  await persistDb();
  renderAll();
}

function renderBudget(){
  const rows = query(`
    SELECT b.*, COALESCE(SUM(e.amount),0) spent
    FROM budgets b
    LEFT JOIN expenses e ON e.category=b.name AND e.month=?
    GROUP BY b.id
    ORDER BY b.id
  `, [activeMonth]);
  el("budgetEditor").innerHTML = rows.map(r => {
    const pct = r.monthly_budget ? Math.min(100, r.spent/r.monthly_budget*100) : 0;
    return `<div class="bar-row ${r.spent>r.monthly_budget?'over':''}">
      <div class="bar-top"><span>${escapeHtml(r.name)}</span><span>${rupee(r.spent)} / ${rupee(r.monthly_budget)}</span></div>
      <div class="bar"><i style="width:${pct}%"></i></div>
      <div class="actions"><button class="secondary" onclick="editBudget(${r.id})">Edit</button><button class="danger" onclick="deleteBudget(${r.id})">Delete</button></div>
    </div>`;
  }).join("");
}

async function addBudget(){
  const name = prompt("Budget item name");
  if (!name) return;
  const amount = Number(prompt("Monthly budget amount", "0") || 0);
  run("INSERT OR IGNORE INTO budgets(name,monthly_budget) VALUES (?,?)", [name, amount]);
  await persistDb();
  renderAll();
}

async function editBudget(id){
  const b = query("SELECT * FROM budgets WHERE id=?", [id])[0];
  const name = prompt("Name", b.name);
  if (!name) return;
  const amount = Number(prompt("Budget amount", b.monthly_budget) || 0);
  run("UPDATE budgets SET name=?, monthly_budget=? WHERE id=?", [name, amount, id]);
  await persistDb();
  renderAll();
}

async function deleteBudget(id){
  if (!confirm("Delete this budget item?")) return;
  run("DELETE FROM budgets WHERE id=?", [id]);
  await persistDb();
  renderAll();
}

function renderPartner(){
  const p = people();
  el("personA").value = p.find(x=>x.code==="A")?.name || "A";
  el("personP").value = p.find(x=>x.code==="P")?.name || "P";
  el("incomeA").value = p.find(x=>x.code==="A")?.monthly_income || 0;
  el("incomeP").value = p.find(x=>x.code==="P")?.monthly_income || 0;
}

async function savePartner(){
  run("UPDATE people SET name=?, monthly_income=? WHERE code='A'", [el("personA").value || "A", Number(el("incomeA").value || 0)]);
  run("UPDATE people SET name=?, monthly_income=? WHERE code='P'", [el("personP").value || "P", Number(el("incomeP").value || 0)]);
  await persistDb();
  renderAll();
  alert("Partner saved");
}

function renderLoan(){
  const l = loan();
  el("loanOriginal").value = l.original || 0;
  el("loanBalance").value = l.balance || 0;
  el("loanEmi").value = l.emi || 0;
  el("loanRate").value = l.rate || 0;

  el("prepayList").innerHTML = prepayments().map(p => `<div class="entry">
    <div><b>${escapeHtml(p.name)}</b><br><small>${rupee(p.amount)} • ${escapeHtml(p.frequency || "")}</small></div>
    <div class="actions"><button class="secondary" onclick="addPrepayExpense(${p.id})">Add Expense</button><button class="secondary" onclick="editPrepay(${p.id})">Edit</button><button class="danger" onclick="deletePrepay(${p.id})">Delete</button></div>
  </div>`).join("");
}

async function saveLoan(){
  run("UPDATE loan SET original=?, balance=?, emi=?, rate=? WHERE id=1", [Number(el("loanOriginal").value), Number(el("loanBalance").value), Number(el("loanEmi").value), Number(el("loanRate").value)]);
  await persistDb();
  renderAll();
  alert("Loan saved");
}

async function addPrepay(){
  const name = prompt("Prepayment name", "Extra Prepayment");
  if (!name) return;
  const amount = Number(prompt("Amount", "50000") || 0);
  const frequency = prompt("Frequency", "Monthly") || "Monthly";
  run("INSERT INTO prepayments(name,amount,frequency) VALUES (?,?,?)", [name, amount, frequency]);
  run("INSERT OR IGNORE INTO budgets(name,monthly_budget) VALUES (?,?)", [name, amount]);
  await persistDb();
  renderAll();
}

async function editPrepay(id){
  const p = query("SELECT * FROM prepayments WHERE id=?", [id])[0];
  const name = prompt("Name", p.name);
  if (!name) return;
  const amount = Number(prompt("Amount", p.amount) || 0);
  const frequency = prompt("Frequency", p.frequency || "Monthly") || "Monthly";
  run("UPDATE prepayments SET name=?, amount=?, frequency=? WHERE id=?", [name, amount, frequency, id]);
  await persistDb();
  renderAll();
}

async function deletePrepay(id){
  if (!confirm("Delete this prepayment option?")) return;
  run("DELETE FROM prepayments WHERE id=?", [id]);
  await persistDb();
  renderAll();
}

function addPrepayExpense(id){
  const p = query("SELECT * FROM prepayments WHERE id=?", [id])[0];
  show("add");
  el("amount").value = p.amount;
  el("category").value = query("SELECT name FROM budgets WHERE name=?", [p.name]).length ? p.name : "Home Loan Prepayment";
  el("description").value = p.name;
  el("payment").value = "Bank Transfer";
  el("date").value = activeMonth + "-01";
}

function renderQuickAdd(){
  const l = loan();
  const items = [
    {name:"EMI", amount:l.emi, cat:"Home Loan EMI", desc:"Monthly EMI"},
    ...prepayments().map(p => ({name:p.name, amount:p.amount, cat:p.name, desc:p.name}))
  ];
  el("quickAdd").className = "quick";
  el("quickAdd").innerHTML = items.map((it,i)=>`<button onclick="quick(${i})"><b>${escapeHtml(it.name)}</b><br><small>${rupee(it.amount)} • ${escapeHtml(it.cat)}</small></button>`).join("");
  window.quickItems = items;
}

function quick(i){
  const it = window.quickItems[i];
  show("add");
  el("amount").value = it.amount;
  el("category").value = it.cat;
  el("description").value = it.desc;
  el("payment").value = "Bank Transfer";
  el("date").value = activeMonth + "-01";
}

function exportSqlite(){
  const data = db.export();
  const blob = new Blob([data], {type:"application/octet-stream"});
  downloadBlob(blob, `expenseflow-${activeMonth}.sqlite`);
}

async function importSqlite(e){
  const file = e.target.files[0];
  if (!file) return;
  if (!confirm("Restore this SQLite database and replace current data?")) return;
  await importSqliteFile(await file.arrayBuffer());
  activeMonth = getSetting("activeMonth") || todayISO().slice(0,7);
  el("monthPicker").value = activeMonth;
  renderAll();
}

function exportCsv(){
  const rows = query("SELECT date,month,paid_by,amount,category,description,payment,reimburse FROM expenses ORDER BY date");
  const csv = [["Date","Month","Paid By","Amount","Category","Description","Payment","Reimburse"], ...rows.map(r => [r.date,r.month,personName(r.paid_by),r.amount,r.category,r.description,r.payment,r.reimburse])]
    .map(r => r.map(v => `"${String(v ?? "").replaceAll('"','""')}"`).join(",")).join("\\n");
  downloadBlob(new Blob([csv], {type:"text/csv"}), "expenseflow-expenses.csv");
}

async function resetDb(){
  if (!confirm("Reset the full SQLite database?")) return;
  db = new SQL.Database();
  createSchema();
  seedInitialDataIfNeeded();
  await persistDb();
  activeMonth = getSetting("activeMonth");
  el("monthPicker").value = activeMonth;
  renderAll();
}

function downloadBlob(blob, name){
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = name;
  a.click();
}

function escapeHtml(str){
  return String(str ?? "").replace(/[&<>"']/g, s => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[s]));
}

# ExpenseFlow SQLite

This is a GitHub Pages-ready finance tracker using SQLite in the browser.

## Important

GitHub Pages is static hosting. It cannot run a server-side SQLite database.

So this app uses:
- `sql.js` for SQLite inside the browser
- IndexedDB to persist the SQLite database file
- Export/import `.sqlite` backups

This is free forever on GitHub Pages, but data is stored on the device/browser. It does not automatically sync across devices.

## Files to upload

Upload these files to your GitHub repo root:

- index.html
- style.css
- db.js
- app.js
- manifest.json
- sw.js
- README.md

## How data works

The app creates a real SQLite database in the browser with tables:

- settings
- people
- budgets
- expenses
- loan
- prepayments

The database is saved into IndexedDB after every change.

## Backup

Go to Backup tab:

- Download SQLite DB
- Restore SQLite DB
- Export CSV

Keep regular `.sqlite` backups in Google Drive or OneDrive.

## GitHub Pages setup

Repo → Settings → Pages → Deploy from branch → main → root.

Then open the GitHub Pages URL in Android Chrome and use Add to Home screen.

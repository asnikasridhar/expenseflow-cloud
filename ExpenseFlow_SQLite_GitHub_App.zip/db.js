let SQL;
let db;
const DB_STORE = "expenseflow_sqlite_db";
const IDB_NAME = "ExpenseFlowSQLite";
const IDB_STORE = "files";

function openIndexedDB(){
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(IDB_NAME, 1);
    request.onupgradeneeded = () => request.result.createObjectStore(IDB_STORE);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function idbGet(key){
  const database = await openIndexedDB();
  return new Promise((resolve, reject) => {
    const tx = database.transaction(IDB_STORE, "readonly");
    const req = tx.objectStore(IDB_STORE).get(key);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function idbSet(key, value){
  const database = await openIndexedDB();
  return new Promise((resolve, reject) => {
    const tx = database.transaction(IDB_STORE, "readwrite");
    tx.objectStore(IDB_STORE).put(value, key);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

async function initDatabase(){
  SQL = await initSqlJs({
    locateFile: file => `https://cdnjs.cloudflare.com/ajax/libs/sql.js/1.10.3/${file}`
  });

  const saved = await idbGet(DB_STORE);
  db = saved ? new SQL.Database(new Uint8Array(saved)) : new SQL.Database();

  createSchema();
  seedInitialDataIfNeeded();
  await persistDb();
}

function createSchema(){
  db.run(`
    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS people (
      code TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      monthly_income REAL NOT NULL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS budgets (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      monthly_budget REAL NOT NULL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS expenses (
      id INTEGER PRIMARY KEY,
      date TEXT NOT NULL,
      month TEXT NOT NULL,
      paid_by TEXT NOT NULL,
      amount REAL NOT NULL,
      category TEXT NOT NULL,
      payment TEXT,
      description TEXT,
      reimburse TEXT DEFAULT 'No'
    );

    CREATE TABLE IF NOT EXISTS loan (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      original REAL,
      balance REAL,
      emi REAL,
      rate REAL
    );

    CREATE TABLE IF NOT EXISTS prepayments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      amount REAL NOT NULL,
      frequency TEXT
    );
  `);
}

function seedInitialDataIfNeeded(){
  const peopleCount = scalar("SELECT COUNT(*) FROM people");
  if (peopleCount === 0) {
    db.run("INSERT INTO people(code,name,monthly_income) VALUES ('A','A',140000),('P','P',223000)");
  }

  const budgetCount = scalar("SELECT COUNT(*) FROM budgets");
  if (budgetCount === 0) {
    const budgets = [
      ["Home Loan EMI",52700],
      ["Home Loan Prepayment",80000],
      ["Compulsory Expenses",100000],
      ["Kids Supplies",25000],
      ["Travel",10000],
      ["Blinkit Wallet",16000],
      ["Amazon Wallet",16000],
      ["Outing",8000],
      ["Investments (Fixed)",55000],
      ["Groceries",10000],
      ["Medical",3000],
      ["Miscellaneous",4000]
    ];
    const stmt = db.prepare("INSERT INTO budgets(name,monthly_budget) VALUES (?,?)");
    budgets.forEach(b => stmt.run(b));
    stmt.free();
  }

  const loanCount = scalar("SELECT COUNT(*) FROM loan");
  if (loanCount === 0) {
    db.run("INSERT INTO loan(id,original,balance,emi,rate) VALUES (1,3300000,3150000,52700,7.5)");
  }

  const prepayCount = scalar("SELECT COUNT(*) FROM prepayments");
  if (prepayCount === 0) {
    db.run("INSERT INTO prepayments(name,amount,frequency) VALUES ('Regular Prepayment',80000,'Monthly'),('Bonus Prepayment',100000,'Occasional')");
  }

  if (!getSetting("activeMonth")) setSetting("activeMonth", new Date().toISOString().slice(0,7));
}

async function persistDb(){
  const data = db.export();
  await idbSet(DB_STORE, data);
}

function query(sql, params = []){
  const stmt = db.prepare(sql);
  stmt.bind(params);
  const rows = [];
  while (stmt.step()) rows.push(stmt.getAsObject());
  stmt.free();
  return rows;
}

function run(sql, params = []){
  const stmt = db.prepare(sql);
  stmt.run(params);
  stmt.free();
}

function scalar(sql, params = []){
  const rows = query(sql, params);
  const first = rows[0];
  if (!first) return null;
  return Object.values(first)[0];
}

function getSetting(key){
  return scalar("SELECT value FROM settings WHERE key = ?", [key]);
}

function setSetting(key, value){
  run("INSERT INTO settings(key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", [key, String(value)]);
}

async function importSqliteFile(arrayBuffer){
  db = new SQL.Database(new Uint8Array(arrayBuffer));
  createSchema();
  seedInitialDataIfNeeded();
  await persistDb();
}
